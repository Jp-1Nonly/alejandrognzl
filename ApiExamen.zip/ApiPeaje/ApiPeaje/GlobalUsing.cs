﻿global using System.ComponentModel.DataAnnotations;
global using Microsoft.EntityFrameworkCore;
global using ApiPeaje.Models;
global using ApiPeaje.Controllers;