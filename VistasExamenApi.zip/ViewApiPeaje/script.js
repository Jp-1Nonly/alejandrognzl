const apiBaseUrl = 'http://localhost:5122/api/Peaje'; 
const externalApiUrl = 'https://www.datos.gov.co/resource/7gj8-j6i3.json';

$(document).ready(function() {
    loadPeajes();
    loadPeajeNames();
});

function loadPeajes() {
    $.get(apiBaseUrl, function(peajes) {
        let peajeTableBody = $('#peajeTableBody');
        peajeTableBody.empty();
        peajes.forEach(peaje => {
            peajeTableBody.append(`
                <tr>
                    <td>${peaje.peajeId}</td>
                    <td>${peaje.placa}</td>
                    <td>${peaje.nombrePeaje}</td>
                    <td>${peaje.idCategoriaTarifa}</td>
                    <td>${peaje.fechaRegistro}</td>
                    <td>${peaje.valor}</td>
                    <td>
                        <button class="btn btn-sm btn-primary" onclick="editPeaje(${peaje.peajeId})">Editar</button>
                        <button class="btn btn-sm btn-danger" onclick="deletePeaje(${peaje.peajeId})">Eliminar</button>
                    </td>
                </tr>
            `);
        });
    });
}

function loadPeajeNames() {
    $.get(externalApiUrl, function(data) {
        let peajeNombre = $('#peajeNombre');
        peajeNombre.empty();
        data.forEach(item => {
            peajeNombre.append(`<option value="${item.peaje}">${item.peaje}</option>`);
        });
    });
}
$('#peajeNombre, #categoriaTarifa').change(function() {
    let peajeNombre = $('#peajeNombre').val();
    let categoriaTarifa = $('#categoriaTarifa').val();
    if (peajeNombre && categoriaTarifa) {
        $.get(externalApiUrl, function(data) {
            let peaje = data.find(item => item.peaje === peajeNombre && item.idcategoriatarifa === categoriaTarifa);
            if (peaje) {
                $('#valorPeaje').val(peaje.valor);
            }
        });
    }
});

$('#peajeForm').submit(function(event) {
    event.preventDefault();
    
    let peajeId = $('#peajeId').val();
    let peajeData = {
        peajeId: peajeId ? parseInt(peajeId) : 0,
        nombrePeaje: $('#peajeNombre').val(),
        placa: $('#peajeplaca').val(),
        idCategoriaTarifa: $('#categoriaTarifa').val(),
        valor: $('#valorPeaje').val()
    };

    if (peajeId) {
        $.ajax({
            url: `${apiBaseUrl}/${peajeId}`,
            type: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify(peajeData),
            success: function() {
                $('#peajeModal').modal('hide');
                loadPeajes();
            },
            error: function(xhr, status, error) {
                console.error('Error al actualizar pago:', xhr.responseText);
            }
        });
    } else {
        $.ajax({
            url: apiBaseUrl,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(peajeData),
            success: function() {
                $('#peajeModal').modal('hide');
                loadPeajes();
            },
            error: function(xhr, status, error) {
                console.error('Error al crear pago:', xhr.responseText);
            }
        });
    }
});
function editPeaje(peajeId) {
    $.get(`${apiBaseUrl}/${peajeId}`, function(peaje) {
        $('#peajeId').val(peaje.peajeId);
        $('#peajeNombre').val(peaje.nombrePeaje);
        $('#peajeplaca').val(peaje.placa);
        $('#categoriaTarifa').val(peaje.idCategoriaTarifa);
        $('#valorPeaje').val(peaje.valor);
        $('#peajeModal').modal('show');
    });
}
function deletePeaje(peajeId) {
    if (confirm('¿Quiere eliminar este pago?')) {
        $.ajax({
            url: `${apiBaseUrl}/${peajeId}`,
            type: 'DELETE',
            success: function() {
                loadPeajes();
            }
        });
    }
}
